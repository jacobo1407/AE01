package ACTIVITAT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.JTextComponent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JScrollPane;
import java.awt.Label;
import java.awt.Button;
import java.awt.TextArea;

public class EVALUABLE extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtDirectori;
	private JTextArea txtaPrincipal;
	private JLabel lblIntroduccio;
	private JButton btnBuscarDirectori;
	private JRadioButton rdbAscendent;
	private JRadioButton rdbDescendent;
	private JScrollPane scrollPane;
	private ArrayList<File> archivosList;
	private JComboBox<String> cmbCriterio;
	private JTextField txtCoincidencies;
	private TextArea txtResultatCoincidencies;
	private Button btnBuscarCoicidencies;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EVALUABLE frame = new EVALUABLE();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EVALUABLE() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 793, 471);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 128, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtDirectori = new JTextField();
		txtDirectori.setBounds(10, 49, 223, 20);
		contentPane.add(txtDirectori);
		txtDirectori.setColumns(10);
		
		lblIntroduccio = new JLabel("Introdueix Directori deseat");
		lblIntroduccio.setBounds(10, 11, 205, 42);
		lblIntroduccio.setFont(new Font("Tahoma", Font.PLAIN, 16));
		contentPane.add(lblIntroduccio);
		
		 btnBuscarDirectori = new JButton("BUSCAR");
		 btnBuscarDirectori.setBounds(267, 80, 89, 23);
		btnBuscarDirectori.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BuscarDirectorio(txtDirectori.getText());
			}
		});
		contentPane.add(btnBuscarDirectori);
		 
		 scrollPane = new JScrollPane();
		 scrollPane.setBounds(10, 131, 346, 236);
		 contentPane.add(scrollPane);
		 
		  txtaPrincipal = new JTextArea();
		  scrollPane.setViewportView(txtaPrincipal);
		
		
		
		 rdbAscendent = new JRadioButton("Ascendent");
		 rdbAscendent.setBounds(6, 80, 109, 23);
		 rdbAscendent.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		 if (rdbAscendent.isSelected()) {
		                ordenarAscendent();
		            }
		 	}
		 });
		contentPane.add(rdbAscendent);
		
		rdbDescendent = new JRadioButton("Descendent");
		rdbDescendent.setBounds(127, 80, 109, 23);
		rdbDescendent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (rdbDescendent.isSelected()) {
		            ordenarDescendent();
		        }
				
			}
		});
		contentPane.add(rdbDescendent);

		 cmbCriterio = new JComboBox<String>();
		 cmbCriterio.setBounds(238, 48, 117, 23);
	        cmbCriterio.addItem("Nom");
	        cmbCriterio.addItem("Tamanyo");
	        cmbCriterio.addItem("Fetxa de Modificacio");
	        contentPane.add(cmbCriterio);
	        
	        txtCoincidencies = new JTextField();
	        txtCoincidencies.setBounds(391, 49, 223, 20);
	        contentPane.add(txtCoincidencies);
	        txtCoincidencies.setColumns(10);
	        
	        Label lblCoincidencies = new Label("Buscaor de Coincidencies");
	        lblCoincidencies.setFont(new Font("Dialog", Font.PLAIN, 16));
	        lblCoincidencies.setBounds(391, 24, 198, 22);
	        contentPane.add(lblCoincidencies);
	        
	        btnBuscarCoicidencies = new Button("BUSCAR");
	        btnBuscarCoicidencies.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		String textoBuscado = txtCoincidencies.getText();
	                buscarCoincidenciasEnArchivos(textoBuscado);
	        	}
	        });
	        btnBuscarCoicidencies.setBounds(391, 81, 70, 22);
	        contentPane.add(btnBuscarCoicidencies);
	        
	        JScrollPane scrollPane_1 = new JScrollPane();
	        scrollPane_1.setBounds(374, 131, 319, 160);
	        contentPane.add(scrollPane_1);
	        
	         txtResultatCoincidencies = new TextArea();
	        scrollPane_1.setViewportView(txtResultatCoincidencies);
	        
	        JButton btnFusionar = new JButton("FUSIONAR");
	        btnFusionar.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		JOptionPane.showMessageDialog(null, "NO IMPLEMENTAT.");
	        	}
	        });
	        btnFusionar.setBounds(372, 318, 117, 23);
	        contentPane.add(btnFusionar);

	        cmbCriterio.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                String criterio = (String) cmbCriterio.getSelectedItem();
	                if (criterio != null) {
	                    if (criterio.equals("Nom")) {
	                        if (rdbAscendent.isSelected()) {
	                            ordenarAscendent();
	                        } else if (rdbDescendent.isSelected()) {
	                            ordenarDescendent();
	                        }
	                    } else if (criterio.equals("Tamanyo")) {
	                        if (rdbAscendent.isSelected()) {
	                            ordenarPorTamanoAscendent();
	                        } else if (rdbDescendent.isSelected()) {
	                            ordenarPorTamanoDescendent();
	                        }
	                    } else if (criterio.equals("Fetxa de Modificacio")) {
	                        if (rdbAscendent.isSelected()) {
	                            ordenarPorFechaAscendent();
	                        } else if (rdbDescendent.isSelected()) {
	                            ordenarPorFechaDescendent();
	                        }
	                    }
	                }
	            }
	        });
	    }
	
	
	/**
	 * Aquest metode agafa la ruta a buscar com un string
	 * per a fer una busqueda de fitxers amb extensio .txt
	 * en el directori indicat i els llista segons els criteris
	 * seleccionats. 
	 * 
	 * @param directorio La ruta del directori
	 */
	public void BuscarDirectorio(String directorio) {
	    File directorioElegido = new File(directorio);

	    if (directorioElegido.exists() && directorioElegido.isDirectory()) {
	        File[] archivos = directorioElegido.listFiles((dir, nombre) -> nombre.endsWith(".txt"));

	        if (archivos != null && archivos.length > 0) {
	            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

	            archivosList = new ArrayList<>();
                for (File archivo : archivos) {
                    archivosList.add(archivo);
                }
                
                
                String criterio = (String) cmbCriterio.getSelectedItem();
                if (criterio != null) {
                    if (criterio.equals("Nom")) {
                        if (rdbAscendent.isSelected()) {
                            ordenarAscendent();
                        } else if (rdbDescendent.isSelected()) {
                            ordenarDescendent();
                        }
                    } else if (criterio.equals("Tamanyo")) {
                        if (rdbAscendent.isSelected()) {
                            ordenarPorTamanoAscendent();
                        } else if (rdbDescendent.isSelected()) {
                            ordenarPorTamanoDescendent();
                        }
                    } else if (criterio.equals("Fetxa de Modificacio")) {
                        if (rdbAscendent.isSelected()) {
                            ordenarPorFechaAscendent();
                        } else if (rdbDescendent.isSelected()) {
                            ordenarPorFechaDescendent();
                        }
                    }}
	          

	            StringBuilder resultadoBusqueda = new StringBuilder();
	            for (File archivo : archivosList) {
	                resultadoBusqueda.append("Nom: " + archivo.getName() + "\n");
	                resultadoBusqueda.append("Extensio: .txt\n");
	                resultadoBusqueda.append("Tamanyo: " + archivo.length() + " bytes\n");
	                resultadoBusqueda.append("ultima fetxa de modificacio: " + formatoFecha.format(new Date(archivo.lastModified())) + "\n\n");
	            }
	            txtaPrincipal.setText(resultadoBusqueda.toString());
	        } else {
	            txtaPrincipal.setText("No se encontraron archivos .txt en el directorio.");
	        }
	    } else {
	        txtaPrincipal.setText("El directorii especificado no existeix.");
	    }
	}

	/**
	 * Aquesta funcio ordena la llista de arxius en ordre alfabetic ascendent pel nom del arxiu.
	 */
	public void ordenarAscendent() {
        if (archivosList != null) {
            Collections.sort(archivosList, (file1, file2) -> file1.getName().compareTo(file2.getName()));
        }
    }
	/**
	 * Aquesta funcio ordena la llista de arxius en ordre alfabetic descendent pel nom del arxiu.
	 */
	public void ordenarDescendent() {
	    if (archivosList != null) {
	        Collections.sort(archivosList, (file1, file2) -> file2.getName().compareTo(file1.getName()));
	    }
	}
	/**
	 * Aquesta funcio ordena la llista de arxius en ordre pel tamany ascendent del arxiu.
	 */
	public void ordenarPorTamanoAscendent() {
        if (archivosList != null) {
            Collections.sort(archivosList, (file1, file2) -> Long.compare(file1.length(), file2.length()));
        }
    }

    /**
     *  Aquesta funcio ordena la llista de arxius en ordre pel tamany descendent del arxiu.
     */
    public void ordenarPorTamanoDescendent() {
        if (archivosList != null) {
            Collections.sort(archivosList, (file1, file2) -> Long.compare(file2.length(), file1.length()));
        }
    }

    /**
     *  Aquesta funcio ordena la llista de arxius en ordre per la data de modificacio de forma ascendent.
     */
    public void ordenarPorFechaAscendent() {
        if (archivosList != null) {
            Collections.sort(archivosList, Comparator.comparingLong(File::lastModified));
        }
    }

    /**
     * Aquesta funcio ordena la llista de arxius en ordre per la data de modificacio de forma descendent.
     */
    public void ordenarPorFechaDescendent() {
        if (archivosList != null) {
            Collections.sort(archivosList, (file1, file2) -> Long.compare(file2.lastModified(), file1.lastModified()));
        }
    }
  
    
    /**
     * Aquesta funcio cerca el text especificat a cada un dels arxius de la llista de arxius.
     * Compta i registra quantes coincidencies hi ha amb el text a cada arxiu i mostra els resultats.
     * 
     * @param textoBuscado Text a buscar en els arxius.
     */
    public void buscarCoincidenciasEnArchivos(String textoBuscado) {
        StringBuilder resultados = new StringBuilder();

        for (File archivo : archivosList) {
            try {
                int coincidencias = contarCoincidenciasEnArchivo(archivo, textoBuscado);
                resultados.append(archivo.getName() + " -> " + coincidencias + " coincidències\n");
            } catch (IOException e) {
                resultados.append(archivo.getName() + " -> Error al llegir l'arxiu\n");
            }
        }

        txtResultatCoincidencies.setText(resultados.toString());
    }

    /**
     *  Aquesta funcio compta i retorna el nombre de coincidencies del text buscat en un arxiu donat.
     * 
     * @param archivo	El arxiu en el qual es buscaran les coincidencies.
     * @param textoBuscado	El text que es vol buscar dins del arxiu.
     * @return El nombre de coincidencies del text trobades al arxiu.
     * @throws IOException
     */
    public int contarCoincidenciasEnArchivo(File archivo, String textoBuscado) throws IOException {
        int coincidencies = 0;
        
        try (Scanner scanner = new Scanner(archivo)) {
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine();
                coincidencies += contarCoincidenciasEnLinea(linea, textoBuscado);
            }
        }

        return coincidencies;
    }

    /**
     * Aquesta funcio compta el nombre de vegades que una cadena de text concreta apareix dins de una linia donada.
     * 
     * @param linea   La linia en la qual es buscara la cadena de text.
     * @param textoBuscado La cadena de text que es vol comptar dins de la linia.
     * @return El numero de vegades que la cadena de text apareix dins de la linia.
     */
    public int contarCoincidenciasEnLinea(String linea, String textoBuscado) {
        int coincidencies = 0;
        int indice = linea.indexOf(textoBuscado);

        while (indice != -1) {
            coincidencies++;
            indice = linea.indexOf(textoBuscado, indice + textoBuscado.length());
        }

        return coincidencies;
    }
}
